// script.js

document.addEventListener('DOMContentLoaded', function () {
    // Get the image element by its ID
    var myPicture = document.getElementById('myPicture');

    // Set the source of the image
    myPicture.src = 'path/to/your/image.jpg'; // Replace with the actual path to your image
    myPicture.alt = 'Your Alt Text'; // Add descriptive alt text for accessibility
});
